package com.example.in_between_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
