import 'dart:math';

import '../core/models/card_model.dart';
import 'deck_manager.dart'; // Assuming Deck class is in deck_manager.dart

class Player {
  String id;
  String name;
  int chips;
  // Other player-specific data like avatar, stats, etc.

  Player({required this.id, required this.name, this.chips = 100});

  bool placeBet(int amount) {
    if (amount <= 0) {
      gameMessage = "Bet amount must be positive.";
      return false;
    }
    if (chips >= amount) {
      chips -= amount;
      return true;
    }
    gameMessage = "$name does not have enough chips.";
    return false;
  }

  void receiveWinnings(int amount) {
    chips += amount;
  }
}

// Global or class-level variable for game messages if not passing Player around
String? gameMessage;

class InBetweenGame {
  late Deck deck;
  List<Player> players;
  int currentPlayerIndex = 0;
  // int pot = 0; // Pot management can be added if it's a shared pot game vs house

  PlayingCard? card1;
  PlayingCard? card2;
  PlayingCard? thirdCard;

  // Game state variables
  bool roundOver = false;
  bool waitingForBet = false;

  InBetweenGame({required this.players}) {
    deck = Deck();
  }

  Player getCurrentPlayer() {
    return players[currentPlayerIndex];
  }

  void startNewRound() {
    deck.resetAndShuffle();
    card1 = deck.dealCard();
    card2 = deck.dealCard();
    thirdCard = null;
    roundOver = false;
    waitingForBet = true;
    gameMessage = "New round started.";

    if (card1 == null || card2 == null) {
      gameMessage = "Error: Could not deal initial cards. Deck empty?";
      roundOver = true;
      waitingForBet = false;
      return;
    }

    // Sort cards by value for easier checking (card1 value <= card2 value)
    if (card1!.value > card2!.value) {
      PlayingCard temp = card1!;
      card1 = card2!;
      card2 = temp;
    }

    // Check for consecutive cards (auto-loss for the player)
    if (card1!.rank != card2!.rank && (card2!.value - card1!.value == 1)) {
      gameMessage = "Consecutive cards dealt! (${card1.toString()} and ${card2.toString()}). No space in between. Player loses ante/fixed amount.";
      // For simplicity, let's assume a fixed loss or loss of a minimum bet if applicable.
      // This part of logic depends on whether an ante is forced.
      // If no forced ante/bet, this might just mean player cannot bet this round or it's a pass.
      // For now, let's just set a message and end the betting phase for this turn.
      roundOver = true; // Or player must pass
      waitingForBet = false;
      // Example: Deduct a small fixed amount if there was an ante
      // int fixedLoss = 5;
      // if(getCurrentPlayer().chips >= fixedLoss) getCurrentPlayer().chips -= fixedLoss;
      // else getCurrentPlayer().chips = 0;
      return;
    }
    
    waitingForBet = true;
    gameMessage = "Cards: ${card1.toString()}, ${card2.toString()}. ${getCurrentPlayer().name}, place your bet.";
  }

  // Returns true if bet was valid and processed, false otherwise
  bool handleBet(Player player, int betAmount) {
    if (!waitingForBet || roundOver) {
      gameMessage = "Not time to bet or round is over.";
      return false;
    }
    // Use the player-specific gameMessage for bet validation
    String? playerBetValidationMessage;
    if (betAmount <= 0) {
      playerBetValidationMessage = "Bet amount must be positive.";
      gameMessage = playerBetValidationMessage;
      return false;
    }
    if (player.chips < betAmount) {
      playerBetValidationMessage = "${player.name} does not have enough chips.";
      gameMessage = playerBetValidationMessage;
      return false;
    }
    
    player.chips -= betAmount; // Deduct bet amount

    waitingForBet = false;
    thirdCard = deck.dealCard();

    if (thirdCard == null) {
      gameMessage = "Error: Deck empty, cannot deal third card.";
      player.receiveWinnings(betAmount); // Return bet if card cannot be dealt
      roundOver = true;
      return false;
    }

    gameMessage = "Third card: ${thirdCard.toString()}.";

    int val1 = card1!.value;
    int val2 = card2!.value;
    int val3 = thirdCard!.value;
    // card1.value is already <= card2.value due to sorting in startNewRound

    bool initialCardsWerePair = (card1!.rank == card2!.rank);

    // 1. Check for TRIPLE outcome (initial pair + third card matches)
    if (initialCardsWerePair && thirdCard!.rank == card1!.rank) {
      int winnings = betAmount * 2; // Wins 2x the bet
      player.receiveWinnings(betAmount + winnings); // Bet back + winnings (total 3x bet)
      gameMessage = "TRIPLE! ${player.name} wins with three ${thirdCard!.rank.name}s! You win $winnings chips (total payout ${betAmount + winnings}).";
    }
    // 2. Check for PAIR outcome (third card matches one of the initial, distinct, cards)
    else if (!initialCardsWerePair && (thirdCard!.rank == card1!.rank || thirdCard!.rank == card2!.rank)) {
      int winnings = betAmount * 1; // Wins 1x the bet
      player.receiveWinnings(betAmount + winnings); // Bet back + winnings (total 2x bet)
      gameMessage = "PAIR! ${player.name} hits a pair with ${thirdCard.toString()}! You win $winnings chips (total payout ${betAmount + winnings}).";
    }
    // 3. Check for IN-BETWEEN outcome (standard win)
    else if (val3 > val1 && val3 < val2) {
      int winnings = betAmount * 1; // Wins 1x the bet (standard 1:1 payout)
      player.receiveWinnings(betAmount + winnings); // Bet back + winnings
      gameMessage = "IN BETWEEN! ${player.name} wins! ${thirdCard.toString()} is between ${card1.toString()} and ${card2.toString()}. You win $winnings chips (total payout ${betAmount + winnings}).";
    }
    // 4. LOSS Condition (Outside, or hits post without special payout, or initial pair and third card doesn't make triple)
    else {
      // Bet is already deducted. No winnings to add.
      if (initialCardsWerePair && thirdCard!.rank != card1!.rank) {
        gameMessage = "${player.name} loses! Initial pair was ${card1!.rank.name}s, third card ${thirdCard.toString()} did not make a triple. You lose $betAmount chips.";
      } else if (val3 == val1 || val3 == val2) { // Hits post, not a special pair payout
         gameMessage = "${player.name} loses! The card ${thirdCard.toString()} hit a post. You lose $betAmount chips.";
      } else { // Outside
        gameMessage = "${player.name} loses! The card ${thirdCard.toString()} is outside. You lose $betAmount chips.";
      }
    }

    roundOver = true;
    return true;
  }

  void nextPlayer() {
    if (players.isNotEmpty) {
      currentPlayerIndex = (currentPlayerIndex + 1) % players.length;
    }
    // Potentially, start new round for the next player here or manage game flow externally
  }
}

