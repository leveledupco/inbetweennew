import 'dart:math';

import 'card_model.dart'; // Assuming card_model.dart is in the same directory or path is adjusted

class Deck {
  List<PlayingCard> cards = [];
  final Random _random = Random();

  Deck() {
    _buildDeck();
    shuffle();
  }

  void _buildDeck() {
    cards.clear();
    for (var suit in CardSuit.values) {
      for (var rank in CardRank.values) {
        cards.add(PlayingCard(suit: suit, rank: rank));
      }
    }
  }

  void shuffle() {
    cards.shuffle(_random);
  }

  PlayingCard? dealCard() {
    if (cards.isEmpty) {
      // Optionally, could rebuild and reshuffle if the game design allows/requires it
      // print("Deck is empty, rebuilding and shuffling...");
      // _buildDeck();
      // shuffle();
      // if (cards.isEmpty) return null; // Should not happen if rebuild is successful
      return null; // Or throw an exception, depending on game rules
    }
    return cards.removeLast();
  }

  void resetAndShuffle() {
    _buildDeck();
    shuffle();
  }

  int get cardsRemaining => cards.length;
}

// Example of how InBetweenGame logic might start (will be expanded significantly)
class InBetweenGameLogic {
  final Deck deck;
  PlayingCard? card1;
  PlayingCard? card2;
  PlayingCard? playerCard;

  InBetweenGameLogic() : deck = Deck();

  void dealInitialCards() {
    card1 = deck.dealCard();
    card2 = deck.dealCard();
    // Ensure card1 and card2 are not null and are different for a valid start
    // (though the game might allow identical initial cards leading to a specific outcome)
    while (card2 == null || (card1 != null && card1!.value == card2!.value)) {
      if (card2 != null) deck.cards.add(card2!); // Put back if same
      deck.shuffle(); // Reshuffle or just take next
      card2 = deck.dealCard();
      if (deck.cardsRemaining < 1 && card2 == null) break; // Avoid infinite loop if deck is too small
    }
  }

  PlayingCard? dealPlayerCard() {
    playerCard = deck.dealCard();
    return playerCard;
  }

  // Returns: 0 for loss, 1 for win, 2 for pair payout, 3 for triple payout
  // This is a simplified version. Payout logic will be more complex.
  int checkWinCondition(PlayingCard cardA, PlayingCard cardB, PlayingCard playerCard) {
    int valA = cardA.value;
    int valB = cardB.value;
    int valPlayer = playerCard.value;

    // Ensure valA < valB for easier comparison
    if (valA > valB) {
      int temp = valA;
      valA = valB;
      valB = temp;
    }

    if (valPlayer > valA && valPlayer < valB) {
      return 1; // Win - In Between
    }
    // User story mentioned special payout for pairs and triples.
    // This needs to be handled at the point of dealing/betting, not just win condition.
    // For now, this function just checks if it's between.
    return 0; // Loss
  }

  // Placeholder for more complex game logic
  // For example, handling betting, player scores, rounds etc.
}

