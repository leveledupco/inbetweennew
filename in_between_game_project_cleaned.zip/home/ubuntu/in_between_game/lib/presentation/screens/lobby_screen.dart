import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../core/services/firestore_service.dart'; // Adjust path as needed
import '../../core/models/game_room_model.dart'; // Adjust path as needed
import '../game_table/game_table_screen.dart'; // Placeholder for GameTableScreen

class LobbyScreen extends StatefulWidget {
  const LobbyScreen({super.key});

  @override
  State<LobbyScreen> createState() => _LobbyScreenState();
}

class _LobbyScreenState extends State<LobbyScreen> {
  final FirestoreService _firestoreService = FirestoreService();
  final User? currentUser = FirebaseAuth.instance.currentUser;

  void _showCreateRoomDialog() {
    TextEditingController roomNameController = TextEditingController();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Create Game Room'),
          content: TextField(
            controller: roomNameController,
            decoration: const InputDecoration(hintText: "Enter room name (optional)"),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Create'),
              onPressed: () async {
                if (currentUser == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('You must be logged in to create a room.')),
                  );
                  Navigator.of(context).pop(); // Close dialog
                  return;
                }
                String roomName = roomNameController.text.trim();
                if (roomName.isEmpty) {
                  // Generate a default room name if none is provided, or use a timestamp
                  roomName = "${currentUser!.displayName ?? currentUser!.email?.split('@').first ?? 'Player'}'s Room";
                }

                GameRoomModel newRoom = GameRoomModel(
                  roomId: '', // Firestore will generate this, or we can generate one
                  roomName: roomName,
                  hostUid: currentUser!.uid,
                  playersUids: [currentUser!.uid], // Host is the first player
                  maxPlayers: 4, // Default or configurable
                  status: 'waiting',
                  createdAt: Timestamp.now(), // Firestore will handle this ideally if set on server
                );

                String? newRoomId = await _firestoreService.createGameRoom(newRoom);
                Navigator.of(context).pop(); // Close dialog
                if (newRoomId != null) {
                  // Navigate to the Game Room (or Game Table Screen directly if host starts)
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => GameTableScreen(roomId: newRoomId, playerUid: currentUser!.uid)),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Failed to create room. Please try again.')),
                  );
                }
              },
            ),
          ],
        );
      },
    );
  }

  void _joinRoom(String roomId) {
    if (currentUser == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('You must be logged in to join a room.')),
      );
      return;
    }
    // In a real scenario, you might want to check if the room is full before navigating
    // or handle it within the GameTableScreen or a pre-join check.
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => GameTableScreen(roomId: roomId, playerUid: currentUser!.uid)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Game Lobby - In Between'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_circle_outline),
            tooltip: 'Create New Room',
            onPressed: _showCreateRoomDialog,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () async {
              await AuthService().signOut();
              // Pop until we are at the root, assuming login is the root or handled by a wrapper
              Navigator.of(context).popUntil((route) => route.isFirst);
            },
          ),
        ],
      ),
      body: StreamBuilder<List<GameRoomModel>>(
        stream: _firestoreService.getAvailableGameRooms(), // Assuming this returns a stream of rooms
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No game rooms available. Create one!'));
          }

          List<GameRoomModel> rooms = snapshot.data!;

          return ListView.builder(
            itemCount: rooms.length,
            itemBuilder: (context, index) {
              GameRoomModel room = rooms[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: ListTile(
                  title: Text(room.roomName ?? 'Unnamed Room'),
                  subtitle: Text('Host: ${room.hostUid.substring(0, 5)}... - Players: ${room.playersUids.length}/${room.maxPlayers} - Status: ${room.status}'),
                  trailing: ElevatedButton(
                    onPressed: () => _joinRoom(room.roomId),
                    child: const Text('Join'),
                  ),
                  onTap: () => _joinRoom(room.roomId), // Allow tapping anywhere on the list item
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// Placeholder for GameTableScreen - this would be a complex widget for the actual game
class GameTableScreen extends StatelessWidget {
  final String roomId;
  final String playerUid;
  const GameTableScreen({super.key, required this.roomId, required this.playerUid});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Game Room: $roomId')),
      body: Center(
        child: Text('Playing game in room $roomId as $playerUid. Gameplay UI to be implemented here.'),
      ),
    );
  }
}

