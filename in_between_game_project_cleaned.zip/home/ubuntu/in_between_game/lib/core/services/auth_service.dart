import 'package:firebase_auth/firebase_auth.dart';
// import 'package:google_sign_in/google_sign_in.dart'; // Uncomment if implementing Google Sign-In

class AuthService {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  // final GoogleSignIn _googleSignIn = GoogleSignIn(); // Uncomment if implementing Google Sign-In

  Stream<User?> get authStateChanges => _firebaseAuth.authStateChanges();

  User? getCurrentUser() {
    return _firebaseAuth.currentUser;
  }

  Future<User?> signUpWithEmailPassword(String email, String password) async {
    try {
      UserCredential credential = await _firebaseAuth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      // Optionally, create a user document in Firestore here after successful sign-up
      // For example, by calling a method from FirestoreService
      return credential.user;
    } on FirebaseAuthException catch (e) {
      // Handle errors (e.g., email-already-in-use, weak-password)
      print('FirebaseAuthException on sign up: ${e.message}');
      throw e; // Rethrow the exception to be handled by the UI
    }
  }

  Future<User?> signInWithEmailPassword(String email, String password) async {
    try {
      UserCredential credential = await _firebaseAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return credential.user;
    } on FirebaseAuthException catch (e) {
      // Handle errors (e.g., user-not-found, wrong-password)
      print('FirebaseAuthException on sign in: ${e.message}');
      throw e; // Rethrow the exception to be handled by the UI
    }
  }

  // Future<User?> signInWithGoogle() async {
  //   // Implement Google Sign-In logic here
  //   // Remember to handle potential errors and null returns
  //   try {
  //     final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
  //     if (googleUser == null) {
  //       // User cancelled the sign-in
  //       return null;
  //     }
  //     final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
  //     final AuthCredential credential = GoogleAuthProvider.credential(
  //       accessToken: googleAuth.accessToken,
  //       idToken: googleAuth.idToken,
  //     );
  //     UserCredential userCredential = await _firebaseAuth.signInWithCredential(credential);
  //     return userCredential.user;
  //   } catch (e) {
  //     print('Error during Google Sign-In: $e');
  //     return null;
  //   }
  // }

  Future<void> signOut() async {
    // if (await _googleSignIn.isSignedIn()) { // Uncomment if implementing Google Sign-In
    //   await _googleSignIn.signOut();
    // }
    await _firebaseAuth.signOut();
  }
}

