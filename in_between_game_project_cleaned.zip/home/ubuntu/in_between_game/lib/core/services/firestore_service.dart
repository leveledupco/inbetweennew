import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart'; // Assuming UserModel is in lib/core/models
import '../models/game_room_model.dart'; // Assuming GameRoomModel is in lib/core/models
import '../models/card_model.dart'; // Assuming PlayingCard is in lib/core/models

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // --- User Profile Methods ---
  Future<void> createUserProfile(UserModel user) async {
    try {
      await _db.collection('users').doc(user.uid).set(user.toJson());
    } catch (e) {
      print('Error creating user profile: $e');
      rethrow; // Rethrow the exception to be handled by the caller
    }
  }

  Future<UserModel?> getUserProfile(String uid) async {
    try {
      DocumentSnapshot doc = await _db.collection('users').doc(uid).get();
      if (doc.exists && doc.data() != null) {
        return UserModel.fromJson(doc.data() as Map<String, dynamic>);
      }
      return null;
    } catch (e) {
      print('Error getting user profile: $e');
      return null;
    }
  }

  Future<void> updateUserChips(String uid, int newChipAmount) async {
    try {
      await _db.collection('users').doc(uid).update({
        'chips': newChipAmount,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('Error updating user chips: $e');
      rethrow;
    }
  }

  // --- Game Room Methods ---
  Future<String?> createGameRoom(GameRoomModel room) async {
    try {
      // Ensure createdAt is set before saving, and convert PlayingCard to JSON
      Map<String, dynamic> roomData = room.toJson();
      roomData['createdAt'] = FieldValue.serverTimestamp(); // Ensure server timestamp
      
      DocumentReference docRef = await _db.collection('game_rooms').add(roomData);
      // Update the room with its own ID for easier querying
      await docRef.update({'roomId': docRef.id});
      return docRef.id;
    } catch (e) {
      print('Error creating game room: $e');
      return null;
    }
  }

  Stream<List<GameRoomModel>> getGameRoomsStream() {
    return _db.collection('game_rooms')
        .where('status', isEqualTo: 'waiting') // Example: Only show waiting rooms
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return GameRoomModel.fromJson(doc.data() as Map<String, dynamic>);
      }).toList();
    });
  }

  Stream<GameRoomModel?> getGameRoomStream(String roomId) {
    return _db.collection('game_rooms').doc(roomId).snapshots().map((snapshot) {
      if (snapshot.exists && snapshot.data() != null) {
        return GameRoomModel.fromJson(snapshot.data() as Map<String, dynamic>);
      }
      return null;
    });
  }

  Future<void> joinRoom(String roomId, String userId) async {
    // This is a simplified join, in a real app, you'd handle capacity, etc.
    // And potentially use a transaction for atomicity.
    DocumentReference roomRef = _db.collection('game_rooms').doc(roomId);
    await roomRef.update({
      'playersUids': FieldValue.arrayUnion([userId])
    });
  }

  Future<void> leaveRoom(String roomId, String userId) async {
    DocumentReference roomRef = _db.collection('game_rooms').doc(roomId);
    await roomRef.update({
      'playersUids': FieldValue.arrayRemove([userId])
    });
  }

  Future<void> updateGameData(String roomId, Map<String, dynamic> data) async {
    await _db.collection('game_rooms').doc(roomId).update(data);
  }

  // Example: Add a card to the game (e.g., when dealing)
  Future<void> addCardToGame(String roomId, PlayingCard card) async {
    await _db.collection('game_rooms').doc(roomId).update({
      'currentCards': FieldValue.arrayUnion([card.toJson()])
    });
  }

  // Example: Clear cards at the end of a round
  Future<void> clearCardsInGame(String roomId) async {
    await _db.collection('game_rooms').doc(roomId).update({
      'currentCards': []
    });
  }

  // Add more methods as needed for game logic, e.g., updating player scores, turns, etc.
}

