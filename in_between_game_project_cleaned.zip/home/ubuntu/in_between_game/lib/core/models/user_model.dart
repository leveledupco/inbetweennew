import 	package:cloud_firestore/cloud_firestore.dart	;

class UserModel {
  final String uid;
  final String? displayName;
  final String? email;
  int chips;
  final Map<String, dynamic>? stats;
  final Timestamp? createdAt;
  final Timestamp? updatedAt;

  UserModel({
    required this.uid,
    this.displayName,
    this.email,
    this.chips = 100, // Default chips
    this.stats,
    this.createdAt,
    this.updatedAt,
  });

  // Factory constructor to create a UserModel from a Firestore document
  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      uid: json["uid"] as String,
      displayName: json["displayName"] as String?,
      email: json["email"] as String?,
      chips: json["chips"] as int? ?? 100,
      stats: json["stats"] as Map<String, dynamic>?,
      createdAt: json["createdAt"] as Timestamp?,
      updatedAt: json["updatedAt"] as Timestamp?,
    );
  }

  // Method to convert UserModel instance to a JSON map for Firestore
  Map<String, dynamic> toJson() {
    return {
      "uid": uid,
      if (displayName != null) "displayName": displayName,
      if (email != null) "email": email,
      "chips": chips,
      if (stats != null) "stats": stats,
      "createdAt": createdAt ?? FieldValue.serverTimestamp(), // Set server timestamp on creation
      "updatedAt": FieldValue.serverTimestamp(), // Always update server timestamp
    };
  }
}

