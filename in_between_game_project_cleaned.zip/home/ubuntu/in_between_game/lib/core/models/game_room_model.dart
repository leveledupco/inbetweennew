import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/card_model.dart'; // Assuming card_model.dart is in lib/core/models/

class GameRoomModel {
  final String roomId;
  final String? roomName;
  final String hostUid;
  final List<String> playersUids; // List of player UIDs
  final int maxPlayers;
  String status; // e.g., "waiting", "in-progress", "finished"
  final Timestamp createdAt;
  int currentPot;
  String? currentPlayerTurnUid;
  List<PlayingCard> currentRoundCards; // Stores the two initial cards
  PlayingCard? lastThirdCard; // Stores the revealed third card
  Map<String, int> bets; // Player UID to bet amount for the current round
  List<String> gameLog;

  GameRoomModel({
    required this.roomId,
    this.roomName,
    required this.hostUid,
    required this.playersUids,
    this.maxPlayers = 4,
    this.status = "waiting",
    required this.createdAt,
    this.currentPot = 0,
    this.currentPlayerTurnUid,
    this.currentRoundCards = const [],
    this.lastThirdCard,
    this.bets = const {},
    this.gameLog = const [],
  });

  factory GameRoomModel.fromJson(Map<String, dynamic> json) {
    return GameRoomModel(
      roomId: json['roomId'] as String,
      roomName: json['roomName'] as String?,
      hostUid: json['hostUid'] as String,
      playersUids: List<String>.from(json['playersUids'] as List? ?? []),
      maxPlayers: json['maxPlayers'] as int? ?? 4,
      status: json['status'] as String? ?? "waiting",
      createdAt: json['createdAt'] as Timestamp,
      currentPot: json['currentPot'] as int? ?? 0,
      currentPlayerTurnUid: json['currentPlayerTurnUid'] as String?,
      currentRoundCards: (json['currentRoundCards'] as List? ?? [])
          .map((cardJson) => PlayingCard.fromJson(cardJson as Map<String, dynamic>))
          .toList(),
      lastThirdCard: json['lastThirdCard'] != null
          ? PlayingCard.fromJson(json['lastThirdCard'] as Map<String, dynamic>)
          : null,
      bets: Map<String, int>.from(json['bets'] as Map? ?? {}),
      gameLog: List<String>.from(json['gameLog'] as List? ?? []),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'roomId': roomId,
      if (roomName != null) 'roomName': roomName,
      'hostUid': hostUid,
      'playersUids': playersUids,
      'maxPlayers': maxPlayers,
      'status': status,
      'createdAt': createdAt,
      'currentPot': currentPot,
      if (currentPlayerTurnUid != null) 'currentPlayerTurnUid': currentPlayerTurnUid,
      'currentRoundCards': currentRoundCards.map((card) => card.toJson()).toList(),
      if (lastThirdCard != null) 'lastThirdCard': lastThirdCard!.toJson(),
      'bets': bets,
      'gameLog': gameLog,
    };
  }
}

