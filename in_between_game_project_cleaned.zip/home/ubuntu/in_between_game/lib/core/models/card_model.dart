import 'dart:math';

enum CardSuit {
  hearts,
  diamonds,
  clubs,
  spades
}

enum CardRank {
  two, three, four, five, six, seven, eight, nine, ten, jack, queen, king, ace
}

class PlayingCard {
  final CardSuit suit;
  final CardRank rank;
  late final int value;
  late final String assetName; // e.g., 'AS.png' for Ace of Spades

  PlayingCard({required this.suit, required this.rank}) {
    // Assign value based on rank (Ace can be tricky, for In-Between, usually low or high)
    // For simplicity in range checks, let's make Ace high (14) for now, or 1 if preferred.
    // The game rules often treat Ace as 1 or 14. Let's use a common approach where Ace is 1 for range calculation initially.
    switch (rank) {
      case CardRank.ace:
        value = 1; // Or 14, depending on game variant rules for In-Between
        break;
      case CardRank.king:
        value = 13;
        break;
      case CardRank.queen:
        value = 12;
        break;
      case CardRank.jack:
        value = 11;
        break;
      default:
        value = rank.index + 2; // two is index 0, so 0+2=2
    }
    assetName = "${rank.name[0].toUpperCase()}${rank.name.substring(1, min(rank.name.length, 2)).toLowerCase()}${suit.name[0].toUpperCase()}.png"; // e.g. AcH.png for Ace of Hearts, 10S.png for 10 of Spades
     // A common asset naming might be RankSuit, e.g., AS.png, KH.png, 10D.png
    String rankSymbol;
    switch (rank) {
      case CardRank.ace: rankSymbol = 'A'; break;
      case CardRank.king: rankSymbol = 'K'; break;
      case CardRank.queen: rankSymbol = 'Q'; break;
      case CardRank.jack: rankSymbol = 'J'; break;
      case CardRank.ten: rankSymbol = 'T'; break;
      default: rankSymbol = (rank.index + 2).toString();
    }
    String suitSymbol = suit.name[0].toUpperCase();
    assetName = '$rankSymbol$suitSymbol.png'; // e.g. AS.png, KH.png, TD.png (for 10 of Diamonds)

  }

  @override
  String toString() {
    return '${rank.name} of ${suit.name} (Value: $value, Asset: $assetName)';
  }
}

